# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) 2004-2010 Tiny SPRL (<http://tiny.be>).
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

# ARNEGSIS

from openerp import fields,models, api
import cx_Oracle


#-----------------------------------
#- * REPORTE ANALISIS DE PEDIDOS * -
#-----------------------------------    
class analisis_pedidos(models.Model):
    
    _name = 'analisis.pedidos'
    _order = 'fecha_digita_pedido asc'
    _rec_name = 'pedido'
    
    compania = fields.Char(string='COMPAÑIA')
    pedido = fields.Char(string='NUMERO PEDIDO')
    fecha_digita_pedido = fields.Datetime(string='FECHA INGRESO PEDIDO')
    
    mes = fields.Char(string='MES')
    anio = fields.Char(string='AÑO')
    
    cliente_codigo = fields.Char(string='CLIENTE CODIGO')
    cliente_descripcion = fields.Char(string='CLIENTE DESCRIPCION')
    estado_pedido = fields.Char(string='ESTADO PEDIDO')
    estado_cerrado = fields.Char(string='ESTADO CERRADO')
    vendedor = fields.Char(string='VENDEDOR')
    cod_vendedor = fields.Char(string='CODIGO VENDEDOR')
    localidad = fields.Char(string='LOCALIDAD')
    #fecha_pedido = fields.Date(string='FECHA PEDIDO')    

    dias_limite = fields.Char(string='DIAS LIMITE')
    eficiencia = fields.Float(string='A tiempo',group_operator="avg")
    no_eficiencia = fields.Float(string='Fuera de tiempo',group_operator="avg")
    fecha_ultima_factura = fields.Datetime(string='ULTIMA FACTURA')
    fecha_ultima_guia = fields.Date(string='ULTIMA GUIA')
    fecha_ultima_planificacion = fields.Date(string='ULTIMA PLANIFICACION')
    diferencia = fields.Char(string='DIFERENCIA')
    atencion = fields.Char(string='ATENCION')
    user_id = fields.Many2one(string='usuario')
    refacturado = fields.Char(string='REFACTURADO')
    oficina = fields.Char(string='OFICINA')

    @api.multi
    def _busca_usuario(self,cod):

	query = "select id from res_users where codigo = '"+str(cod)+"' "
	self._cr.execute(query)
	res = self._cr.dictfetchall()
	if res != []:
	   iden = res[0]['id']
	else:
	   iden = False
	return iden

    @api.multi
    def fecha(self,dt):
        if dt != None:
	  FCH = dt[6:10]+'-'+dt[3:5]+'-'+dt[0:2]+' '+dt[11:19]
	  return FCH
        if dt is None: 
          FCH = ''
          return FCH

    @api.multi
    def mes_cnv(self,psc):
	dct=['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre']
	return dct[int(psc)-1]
  
    @api.multi
    def import_data(self,):
	print 'Importar pedidos'
	self._cr.execute("TRUNCATE TABLE analisis_pedidos")
	self._cr.commit()
	dct = {}
	conn_str='openside/masejo072431@172.16.1.251:1521/proqimsa'
	db_conn = cx_Oracle.connect(conn_str)
	cursor = db_conn.cursor()
	cursor.execute("ALTER SESSION SET NLS_DATE_FORMAT = 'YYYY-MM-DD HH24:MI:SS' NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH24:MI:SS.FF'")
	#cursor.execute('SELECT compania,pedido,fecha_digitacion_pedido,mes,anio,cliente_codigo,cliente_descripcion,estado_pedido,estado_cerrado,vendedor,cod_vendedor, localidad,fecha_pedido,dias_limite,eficiencia,no_eficiencia,fecha_ultimafactura,  fecha_ultimaguia,fecha_ultimaplanificacion,diferencia,a_tiempo,refacturado FROM openside.WEB_REP_ATENCION_PEDIDOS')
	cursor.execute('SELECT compania,pedido,fecha_digitacion_pedido,mes,anio,cliente_codigo,cliente_descripcion,estado_pedido,estado_cerrado,vendedor,cod_vendedor, localidad,dias_limite,eficiencia,no_eficiencia,fecha_ultimafactura,  fecha_ultimaguia,fecha_ultimaplanificacion,diferencia,a_tiempo,refacturado,oficina FROM openside.WEB_REP_ATENCION_PEDIDOS')

	#registros = cursor.dictfetchall()
	registros = cursor.fetchall()
	for r in registros:
            mi_lista = list(r)
            dct = {'compania':mi_lista[0],
		    'pedido':mi_lista[1],
		    'fecha_digita_pedido':self.fecha(mi_lista[2]),
		    'mes':self.mes_cnv(mi_lista[3]),
		    'anio':mi_lista[4],
		    'cliente_codigo':mi_lista[5],
		    'cliente_descripcion':mi_lista[6],
		    'estado_pedido':mi_lista[7],
		    'estado_cerrado':mi_lista[8],
		    'vendedor':mi_lista[9],
		    'cod_vendedor':mi_lista[10],
		    'localidad':mi_lista[11],
		   # 'fecha_pedido':mi_lista[12],
		    'dias_limite':mi_lista[12],
		    'eficiencia':mi_lista[13],
		    'no_eficiencia':mi_lista[14],
		    'fecha_ultima_factura':self.fecha(mi_lista[15]) or False,
		    'fecha_ultima_guia':self.fecha(mi_lista[16]) or False,
		    'fecha_ultima_planificacion':self.fecha(mi_lista[17]) or False,
		    'diferencia':mi_lista[18],
		    'atencion':mi_lista[19],
		    'user_id': int(self._busca_usuario(mi_lista[10])) or False,
                    'refacturado':mi_lista[20],
                    'oficina':mi_lista[21]
		}
									    
            self.create(dct)
	return True


